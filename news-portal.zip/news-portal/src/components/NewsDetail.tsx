import React from 'react';
import { News } from '../types/types';

interface NewsDetailProps {
  news: News;
}

const NewsDetail: React.FC<NewsDetailProps> = ({ news }) => {
  return (
    <div className="news-detail">
      <h1 className="news-detail-title">{news.title}</h1>
      <p className="news-detail-date">{news.date}</p>
      <img src={news.image} alt={news.title} className="news-detail-image" />
      <div className="news-detail-content">
        {news.content.split('\n').map((paragraph, index) => (
          <p key={index}>{paragraph}</p>
        ))}
      </div>
      <div className="news-detail-categories">
        {news.categories.map((category, index) => (
          <span key={index} className="news-detail-category">{category}</span>
        ))}
      </div>
    </div>
  );
};

export default NewsDetail;


