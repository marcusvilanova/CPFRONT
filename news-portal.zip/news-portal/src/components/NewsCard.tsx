import React from 'react';
import { News } from '../types/types';
import { Link } from 'react-router-dom';

interface NewsCardProps {
  news: News;
}

const NewsCard: React.FC<NewsCardProps> = ({ news }) => {
  const truncateContent = (text: string, limit: number) => {
    if (text.length <= limit) return text;
    return text.slice(0, limit) + '...';
  };

  return (
    <div className="news-card">
      <img src={news.image} alt={news.title} className="news-card-image" />
      <div className="news-card-content">
        <h3 className="news-card-title">{news.title}</h3>
        <p className="news-card-date">{news.date}</p>
        <p className="news-card-excerpt">{truncateContent(news.content, 50)}</p>
        <div className="news-card-categories">
          {news.categories.map((category, index) => (
            <span key={index} className="news-card-category">{category}</span>
          ))}
        </div>
        <Link to={`/news/${news.id}`} className="news-card-link">Leia mais</Link>
      </div>
    </div>
  );
};

export default NewsCard;


