import React from 'react';
import { Comment } from '../types/types';

interface CommentsProps {
  comments: Comment[];
}

const Comments: React.FC<CommentsProps> = ({ comments }) => {
  return (
    <div className="comments-section">
      <h2>Comentários</h2>
      {comments.length === 0 ? (
        <p>Nenhum comentário ainda.</p>
      ) : (
        comments.map((comment, index) => (
          <div key={index} className="comment-item">
            <p><strong>{comment.name}:</strong> {comment.text}</p>
          </div>
        ))
      )}
    </div>
  );
};

export default Comments;


