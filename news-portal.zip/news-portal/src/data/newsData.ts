import { News } from '../types/types';

export const newsData: News[] = [
  {
    id: '1',
    title: 'Notícia 1: Lorem Ipsum Dolor Sit Amet',
    date: '2025-09-24',
    content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
    image: 'https://via.placeholder.com/150',
    categories: ['Tecnologia', 'Geral'],
    comments: [
      { name: 'Usuário A', text: 'Ótimo artigo!' },
      { name: 'Usuário B', text: 'Muito informativo.' },
    ],
  },
  {
    id: '2',
    title: 'Notícia 2: Consectetur Adipiscing Elit',
    date: '2025-09-23',
    content: 'Consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
    image: 'https://via.placeholder.com/150',
    categories: ['Esportes'],
    comments: [
      { name: 'Usuário C', text: 'Interessante!' },
    ],
  },
  {
    id: '3',
    title: 'Notícia 3: Sed Do Eiusmod Tempor',
    date: '2025-09-22',
    content: 'Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
    image: 'https://via.placeholder.com/150',
    categories: ['Política', 'Geral'],
    comments: [],
  },
  {
    id: '4',
    title: 'Notícia 4: Incididunt Ut Labore Et Dolore',
    date: '2025-09-21',
    content: 'Incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
    image: 'https://via.placeholder.com/150',
    categories: ['Economia'],
    comments: [
      { name: 'Usuário D', text: 'Preciso ler mais sobre isso.' },
    ],
  },
  {
    id: '5',
    title: 'Notícia 5: Magna Aliqua Ut Enim Ad Minim',
    date: '2025-09-20',
    content: 'Magna aliqua ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
    image: 'https://via.placeholder.com/150',
    categories: ['Tecnologia'],
    comments: [
      { name: 'Usuário E', text: 'Novidades interessantes!' },
      { name: 'Usuário F', text: 'Ansioso por mais.' },
    ],
  },
  {
    id: '6',
    title: 'Notícia 6: Veniam Quis Nostrud Exercitation',
    date: '2025-09-19',
    content: 'Veniam quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
    image: 'https://via.placeholder.com/150',
    categories: ['Mundo'],
    comments: [],
  },
  {
    id: '7',
    title: 'Notícia 7: Ullamco Laboris Nisi Ut Aliquip',
    date: '2025-09-18',
    content: 'Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
    image: 'https://via.placeholder.com/150',
    categories: ['Saúde'],
    comments: [
      { name: 'Usuário G', text: 'Informações cruciais.' },
    ],
  },
  {
    id: '8',
    title: 'Notícia 8: Ex Ea Commodo Consequat Duis',
    date: '2025-09-17',
    content: 'Ex ea commodo consequat duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
    image: 'https://via.placeholder.com/150',
    categories: ['Educação'],
    comments: [
      { name: 'Usuário H', text: 'Ótima iniciativa!' },
    ],
  },
  {
    id: '9',
    title: 'Notícia 9: Aute Irure Dolor In Reprehenderit',
    date: '2025-09-16',
    content: 'Aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
    image: 'https://via.placeholder.com/150',
    categories: ['Ciência'],
    comments: [
      { name: 'Usuário I', text: 'Artigo bem escrito.' },
      { name: 'Usuário J', text: 'Gostei muito.' },
    ],
  },
  {
    id: '10',
    title: 'Notícia 10: Voluptate Velit Esse Cillum Dolore',
    date: '2025-09-15',
    content: 'Voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
    image: 'https://via.placeholder.com/150',
    categories: ['Entretenimento'],
    comments: [],
  },
];


