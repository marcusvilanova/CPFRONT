export interface Comment {
  name: string;
  text: string;
}

export interface News {
  id: string;
  title: string;
  date: string;
  content: string;
  image: string;
  categories: string[];
  comments: Comment[];
}


