import React, { useState, useEffect } from 'react';
import NewsList from '../components/NewsList';
import { newsData } from '../data/newsData';
import { News } from '../types/types';

const HomePage: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredNews, setFilteredNews] = useState<News[]>([]);

  useEffect(() => {
    const lowerCaseSearchTerm = searchTerm.toLowerCase();
    const results = newsData.filter(
      (newsItem) =>
        newsItem.title.toLowerCase().includes(lowerCaseSearchTerm) ||
        newsItem.content.toLowerCase().includes(lowerCaseSearchTerm) ||
        newsItem.categories.some((category) =>
          category.toLowerCase().includes(lowerCaseSearchTerm)
        )
    );
    setFilteredNews(results);
  }, [searchTerm]);

  return (
    <div className="home-page">
      <header className="header">
        <h1>Portal de Notícias</h1>
        <input
          type="text"
          placeholder="Buscar notícias..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="search-input"
        />
      </header>
      <main>
        {filteredNews.length > 0 ? (
          <NewsList news={filteredNews} />
        ) : (
          <p className="no-articles-message">Nenhum artigo encontrado.</p>
        )}
      </main>
      <footer className="footer">
        <p>Nome Completo e RA do Trio</p>
      </footer>
    </div>
  );
};

export default HomePage;


