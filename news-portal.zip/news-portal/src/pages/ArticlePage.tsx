import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { newsData } from '../data/newsData';
import NewsDetail from '../components/NewsDetail';
import Comments from '../components/Comments';
import { News } from '../types/types';

const ArticlePage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [newsArticle, setNewsArticle] = useState<News | undefined>(undefined);

  useEffect(() => {
    const article = newsData.find(news => news.id === id);
    setNewsArticle(article);
  }, [id]);

  if (!newsArticle) {
    return <p>Notícia não encontrada.</p>;
  }

  return (
    <div className="article-page">
      <nav className="article-nav">
        <Link to="/" className="back-button">Voltar para a Home</Link>
      </nav>
      <NewsDetail news={newsArticle} />
      <Comments comments={newsArticle.comments} />
    </div>
  );
};

export default ArticlePage;


