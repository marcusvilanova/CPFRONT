# News Portal Project

This project is a news portal built with React, as specified in the Checkpoint 05 activity.

## Features
- List news from a static array.
- Filter news by title, content, and categories.
- View full news article with comments.
- Custom 404 page.
- Responsive layout.

## Project Structure
```
news-portal/
├── public/
├── src/
│   ├── assets/ (for images, etc.)
│   ├── components/
│   │   ├── Comments.tsx
│   │   ├── NewsCard.tsx
│   │   └── NewsList.tsx
│   ├── data/
│   │   └── newsData.ts
│   ├── pages/
│   │   ├── ArticlePage.tsx
│   │   ├── HomePage.tsx
│   │   └── NotFoundPage.tsx
│   ├── types/
│   │   └── types.ts
│   ├── App.tsx
│   ├── index.css
│   └── index.tsx
├── .gitignore
├── package.json
├── package-lock.json (or yarn.lock)
└── README.md
```

## Setup and Run

1.  **Clone the repository (if applicable) or extract the ZIP file.**

2.  **Navigate to the project directory:**
    ```bash
    cd news-portal
    ```

3.  **Install dependencies:**
    ```bash
    npm install
    # or yarn install
    ```

4.  **Start the development server:**
    ```bash
    npm start
    # or yarn start
    ```

    The application will open in your browser at `http://localhost:3000`.

## Deployment on Vercel

1.  **Push your project to a Git repository (e.g., GitHub).**

2.  **Sign up or log in to Vercel (vercel.com).**

3.  **Import your Git repository to Vercel.**

4.  **Follow the Vercel deployment steps.** Ensure the build command is `npm run build` (or `yarn build`) and the output directory is `build`.

5.  **Add the public link to your deployed project here:**
    `[YOUR_VERCEL_DEPLOYMENT_LINK_HERE]`

## Trio Information

**Nome Completo e RA do Trio**
- Membro 1: [Nome Completo] - [RA]
- Membro 2: [Nome Completo] - [RA]
- Membro 3: [Nome Completo] - [RA]

